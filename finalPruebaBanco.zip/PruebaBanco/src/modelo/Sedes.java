package modelo;
import java.util.Scanner;
public class Sedes {
    Scanner entrada= new Scanner(System.in);
    private String nombre,direccion,ciudad;
    private int codigo;
    private Cuentas cuentas[];//debido a la relacion de composicion
    
    private static final int max_cuentas = 10;
    public Sedes(String nombre, String direccion, String ciudad, int codigo) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.codigo = codigo;
    }
    
    public Sedes() {
        this.cuentas=new Cuentas[max_cuentas];
    }
    

    public int getCoidgo() {
        return codigo;
    }

    public void setCoidgo(int coidgo) {
        this.codigo = coidgo;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    public Cuentas[] getCuentas() {
        return cuentas;
    }

    public void setCuentas(Cuentas[] cuentas) {
        this.cuentas = cuentas;
    }
    public void crearCuenta(){
        System.out.println("--------------------------------------");
        System.out.println("escriba el numero de cuentas que necesita crear (MAX 10): ");
        int numCuentas=entrada.nextInt();
        for (int i=0;i<numCuentas & numCuentas<max_cuentas;i++){
            System.out.println("escriba la cedula: ");
            int cc=entrada.nextInt();
            System.out.println("escriba el tipo de cuenta: ");
            String tipoCuenta=entrada.next();
            System.out.println("escriba el saldo inicial: ");
            double saldoInicial=entrada.nextDouble();
            System.out.println("titular de la cuenta: ");
            String titular=entrada.next();
            cuentas[i]=new Cuentas(cc, tipoCuenta, saldoInicial, titular);
        }    
    }
    public void consultarCuentas(){
        System.out.println("--------------------------------------");
        System.out.println("cuentas creadas del banco ");
        for (Cuentas cuenta : cuentas)
        {
            System.out.println("numero de cuenta: "+cuenta.getNo_cuenta()+"\ntipo de cuenta: "+cuenta.getTipo_cuenta()+
                    "\nsaldo inicial: "+cuenta.getSaldo_Inicial()+"\ntitular de la cuenta: "+cuenta.getTitular());
        }
    }
    public String tosString(){
        return "nombre de la sede: "+this.nombre+"\ndireccion: "+this.direccion+"ciudad: "+"\ncodigo: "+this.codigo; 
    }
}
