package modelo;
import java.util.Scanner;
public class Banco {
    Scanner entrada= new Scanner(System.in);
    private String nombre_banco;
 
    private Sedes sede[];//relacion de composicion 

    
    private static final int max_sedes = 5;
    
    public Banco() {//constructor debido a la relacion de composicion 
        this.sede=new Sedes[max_sedes];
    }
    
    public Banco(String nombre_banco) {
        this.nombre_banco = nombre_banco;
        
    }
    public Sedes[] getSede() {
        return sede;
    }

    public void setSede(Sedes[] sede) {
        this.sede = sede;
    }
    public String getNombre_banco() {
        return nombre_banco;
    }

    public void setNombre_banco(String nombre_banco) {
        this.nombre_banco = nombre_banco;
    }
    public void crearSede(){
        System.out.println("--------------------------------------");
        System.out.println("cuantas sedes desea crear (MAX 5): ");
        int numSedes=entrada.nextInt();
        
        for (int i=0;i<numSedes & numSedes<max_sedes;i++){
            System.out.println("escriba el nombre de la sede: ");
            String nombre=entrada.next();
            System.out.println("escriba la direccio de la sede: ");
            String direccion=entrada.next();
            System.out.println("escriba la ciudad de la sede: ");
            String ciudad=entrada.next();
            System.out.println("escriba el codigo de la sede (valor entero): ");
            int codigo=entrada.nextInt();
            sede[i]=new Sedes(nombre,direccion,ciudad,codigo);
        }

    }
    public void consultarSede(){
        System.out.println("--------------------------------------");
        System.out.println("sedes creadas del banco ");
        for (Sedes sedes : sede)
        {
            System.out.println("nombre de la sede: "+sedes.getNombre()+"\ndireccionde la sede: "+sedes.getDireccion()+"\nciudad donde esta la sede: "+sedes.getCiudad()+
                    "\ncodigo de la sede: "+sedes.getCoidgo());
        } 
    }
    public String tosString(){
        return "nombre del banco: "+getNombre_banco()+"\nnumero de sedes: "+max_sedes;
    } 
}
