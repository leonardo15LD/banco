
package modelo;
public class Titular {
    private int cc;
    private String nombre,apellido,codigo;
    private String sexo;

    public Titular(int cc, String nombre, String apellido, String sexo) {
        this.cc = cc;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sexo = sexo;
    }

    public Titular() {
    }

    Titular(int cc, String tipoCuenta, double saldoInicial, String sexo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public String tosString(){
        return "cedula: "+this.cc+"\nnombre: "+this.nombre+"\napellido: "+this.apellido+"\nsexo: "+this.sexo;
    }
    
}
