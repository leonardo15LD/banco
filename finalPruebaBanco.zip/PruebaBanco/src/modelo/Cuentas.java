
package modelo;
public class Cuentas {
    private int No_cuenta;
    private Titular titular;//relacion de agregacion
    public Cuentas(Titular titular) {
        this.titular = titular;
    }
    private String Tipo_cuenta;
    private double Saldo_Inicial;
    private String titularCuenta;

    public Cuentas() {
    }
    
    public Cuentas(int No_cuenta,String Tipo_cuenta, double Saldo_Inicial, String titularCuenta) {
        this.No_cuenta=No_cuenta;
        this.Tipo_cuenta = Tipo_cuenta;
        this.Saldo_Inicial = Saldo_Inicial;
        this.titularCuenta = titularCuenta;
    }
    public int getNo_cuenta() {
        return No_cuenta;
    }

    public void setNo_cuenta(int No_cuenta) {
        this.No_cuenta = No_cuenta;
    }

    public String getTipo_cuenta() {
        return Tipo_cuenta;
    }

    public void setTipo_cuenta(String Tipo_cuenta) {
        this.Tipo_cuenta = Tipo_cuenta;
    }

    public double getSaldo_Inicial() {
        return Saldo_Inicial;
    }

    public void setSaldo_Inicial(double Saldo_Inicial) {
        this.Saldo_Inicial = Saldo_Inicial;
    }
    public Titular getTitular() {
        return titular;
    }

    public void setTitular(Titular titular) {
        this.titular = titular;
    }
    public String toString(){
        return "numero de cuenta: "+this.No_cuenta+"\ntipo de cuenta: "+this.Tipo_cuenta+"\nsaldo inicial: "+this.Saldo_Inicial+
                "\ntitular de la cuenta: "+this.titular;
    }
}
