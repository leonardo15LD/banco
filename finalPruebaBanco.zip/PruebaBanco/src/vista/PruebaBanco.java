
package vista;
import modelo.*;
import java.util.Scanner;
public class PruebaBanco {
    
    Scanner entrada= new Scanner(System.in);
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        PruebaBanco banco=new PruebaBanco();//creacion del banco
        Banco sedes=new Banco();
        
        
        Sedes cuentas=new Sedes();
        int opcion;
        do{
            System.out.println("1. Crear Banco");     
            System.out.println("2. Crear sedes bancarias");
            System.out.println("3. Consultar sedes bancarias");
            System.out.println("4. Crear cuentas");
            System.out.println("5. Consultar cuenta");
            System.out.println("6. salir del menu");
            System.out.println("escoja una Opción: ");
            opcion=entrada.nextInt();
        switch(opcion){
            case 1 ->
                {
                    banco.crearBanco();
                    System.out.println("banco creado con exito");
                }
            case 2 ->
                {
                    sedes.crearSede();
                    System.out.println("sedes creadas con exito");
                }
            case 3 ->
                {
                    sedes.consultarSede();
                    System.out.println("sedes del banco consultadas con exito");
                }
            case 4 ->
                {
                    cuentas.crearCuenta();
                    System.out.println("cuentas creadas con exito");
                }
            case 5 ->
                {
                    cuentas.consultarCuentas();
                    System.out.println("cuentas del banco consultadas con exito");
                }
            case 6 -> System.out.println("programa finalizado ");
            }
        }while(opcion!=6);
    }
    
    public  void crearBanco (){
        System.out.println("escriba el nombre del banco: ");
        String nombre_banco=entrada.nextLine();
        Banco banco=new Banco(nombre_banco);
    }
    
}
